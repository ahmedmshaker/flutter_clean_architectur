import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../domain/[feature_name]UseCase.dart';
import 'package:injectable/injectable.dart';
import '[feature_name]State.dart';
import 'package:hassala_kids_flutter/features/[feature_name]/data/models/[feature_name]Request.dart';
import 'package:hassala_kids_flutter/core/common/extension/ResponseExtension.dart';
import 'package:hassala_kids_flutter/features/[feature_name]/data/models/[feature_name]Response.dart';
import 'package:hassala_kids_flutter/core/base/data/error/ResponseErorr.dart';

@injectable
class [feature_name]Cubit extends Cubit<[feature_name]State> {
final [feature_name]UseCase _[feature_name]UseCase;

[feature_name]Cubit(this._[feature_name]UseCase): super(Initial[feature_name]State());


Future<void> [feature_name](String body) async {
try {
emit(Loading[feature_name]State());
final response = await _[feature_name]UseCase.call([feature_name]Request(body:body));
var result = response.getResult();
if (result is [feature_name]Response) {
emit(Success[feature_name]State(result));
} else if (result is ErrorMessageFailure) {
emit(ErrorMessage[feature_name]State(result.errorMessage));
}
} catch (e) {
emit(ErrorMessage[feature_name]State(e.toString()));
}
}
}
