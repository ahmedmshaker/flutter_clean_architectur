import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';


import 'package:hassala_kids_flutter/features/[feature_name]/data/models/[feature_name]Response.dart';

@immutable
abstract class [feature_name]State extends Equatable {}

class Initial[feature_name]State extends [feature_name]State {
  @override
  List<Object> get props => [];
}

class Loading[feature_name]State extends [feature_name]State {
@override
List<Object> get props => [];
}

class Success[feature_name]State extends [feature_name]State {
[feature_name]Response response;
Success[feature_name]State(this.response);

@override
List<Object> get props => [];
}






class ErrorMessage[feature_name]State extends [feature_name]State {
final String errorMessage;

ErrorMessage[feature_name]State(this.errorMessage);

@override
List<Object> get props => [];
}


class NoInternet[feature_name]State extends [feature_name]State {


NoInternet[feature_name]State();

}



