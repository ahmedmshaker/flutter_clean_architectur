import 'package:hassala_kids_flutter/di/InjectionContainer.dart';
import 'package:flutter/material.dart';
import 'package:hassala_kids_flutter/utilities/CommonImports.dart';
import '../cubit/[feature_name]State.dart';
import 'package:hassala_kids_flutter/features/[feature_name]/presentation/cubit/[feature_name]Cubit.dart';


class [feature_name]Screen extends StatefulWidget {
@override
_[feature_name]ScreenState createState() => _[feature_name]ScreenState();
}

class _[feature_name]ScreenState extends State<[feature_name]Screen> {
[feature_name]Cubit _[feature_name]Cubit;

@override
void initState() {
super.initState();
_[feature_name]Cubit = getIt<[feature_name]Cubit>();

}

@override
Widget build(BuildContext context) {
      return BlocProvider(
         create: (context) => _[feature_name]Cubit,
        child: BlocBuilder<[feature_name]Cubit, [feature_name]State>(
           builder: (context, state) {
          return Container();
                       },
                       )

                        );
                   }
                }
