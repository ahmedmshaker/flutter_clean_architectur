import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:hassala_kids_flutter/core/base/data/error/ResponseErorr.dart';
import 'package:hassala_kids_flutter/core/base/domain/BaseUseCase.dart';

import '../data/repository/[feature_name]Repository.dart';
import 'package:injectable/injectable.dart';
import 'package:hassala_kids_flutter/features/[feature_name]/data/models/[feature_name]Request.dart';
import 'package:hassala_kids_flutter/features/[feature_name]/data/models/[feature_name]Response.dart';

@injectable
class [feature_name]UseCase implements BaseUseCase<[feature_name]Response, [feature_name]Request> {
  final [feature_name]Repository repository;

  const [feature_name]UseCase(this.repository);

  @override
  Future<Either<ResponseError, [feature_name]Response>> call([feature_name]Request request) {
try {
  return Future.value(Right(null));
} catch (e) {
return Future.value(Left(ErrorMessageFailure(e.errorMessage)));
}
  }
}
