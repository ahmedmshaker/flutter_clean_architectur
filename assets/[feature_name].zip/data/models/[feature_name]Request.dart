  import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class [feature_name]Request extends Equatable {
  final String body;

  [feature_name]Request( {@required this.body});
  @override
  List<Object> get props => [];
  }
