

class [feature_name]Response{


[feature_name]Response.fromJson(Map<String, dynamic> json) {

}

Map<String, dynamic> toJson() {
final Map<String, dynamic> data = new Map<String, dynamic>();

return data;
}

}