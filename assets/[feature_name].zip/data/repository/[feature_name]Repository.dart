
abstract class [feature_name]Repository{

}