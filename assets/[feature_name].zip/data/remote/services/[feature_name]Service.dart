

import 'package:dio/dio.dart';
import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';

part '[feature_name]Service.g.dart';

@RestApi()
@injectable
abstract class [feature_name]Service{

  @factoryMethod
  factory [feature_name]Service(Dio dio) = _[feature_name]Service;


}