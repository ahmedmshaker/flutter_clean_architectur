abstract class [feature_name]RemoteDataSource {}
